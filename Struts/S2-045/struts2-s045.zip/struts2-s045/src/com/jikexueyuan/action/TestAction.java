package com.jikexueyuan.action;

public class TestAction {

	public String execute(){
		return "test";
	}
}
