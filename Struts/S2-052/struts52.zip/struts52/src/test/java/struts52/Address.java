package struts52;

/**
 * @author 北方的河 E-mail: 2280274936@qq.com
 * @version 创建时间：2017年9月9日 下午5:20:11 类说明
 */
public class Address {
	private String add;
	private String zipcode;

	public Address(String add, String zipcode) {
		this.add = add;
		this.zipcode = zipcode;
	}

	public String toString() {
		return "Address{" + "add='" + add + '\'' + ", zipcode='" + zipcode + '\'' + '}';
	}
}
