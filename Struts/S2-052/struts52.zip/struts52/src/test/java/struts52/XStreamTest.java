package struts52;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

import com.thoughtworks.xstream.XStream;

/**
 * @author 北方的河 E-mail: 2280274936@qq.com
 * @version 创建时间：2017年9月9日 下午5:21:02 类说明
 */
public class XStreamTest {
	public static void main(String args[]) throws Exception {
		test();
	}

	private static void test() throws FileNotFoundException {
		XStream xStream2 = new XStream();
		InputStreamReader in = new InputStreamReader(new FileInputStream("payload.xml"));
		xStream2.fromXML(in);
	}

}