package struts52;

/**
* @author 北方的河 E-mail: 2280274936@qq.com
* @version 创建时间：2017年9月9日 下午5:19:23
* 类说明
*/
import java.util.List;

public class Person {
	private String name;
	private String age;
	private Profile profile;
	private List<Address> addlist;

	public Person(String name, String age, Profile profile, List<Address> addlist) {
		this.name = name;
		this.age = age;
		this.profile = profile;
		this.addlist = addlist;
	}

	public Person() {

	}

	public String toString() {
		return "Person{" + "name='" + name + '\'' + ", age='" + age + '\'' + ", profile=" + profile + ", addlist="
				+ addlist + '}';
	}
}
