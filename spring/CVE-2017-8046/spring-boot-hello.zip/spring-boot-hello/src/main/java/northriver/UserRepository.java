package northriver;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
* @author 北方的河 E-mail: 2280274936@qq.com
* @version 创建时间：2017年9月30日 下午11:03:48
* 类说明
*/
@RepositoryRestResource(path="user")
public interface UserRepository extends JpaRepository<User, Long>{

}
