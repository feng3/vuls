package northriver;

import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpression;
import org.springframework.expression.spel.standard.SpelExpressionParser;

/**
 * @author 北方的河 E-mail: 2280274936@qq.com
 * @version 创建时间：2017年10月1日 上午8:08:49 类说明
 */
public class TestSPEL {

	public static void main(String[] args) {
		ExpressionParser parser = new SpelExpressionParser();
		String expression1 = "T(java.lang.Runtime).getRuntime().exec(\"calc\")";
		String expression2 = "new java.lang.ProcessBuilder(\"calc\").start()";
		String expression3 = "new java.lang.ProcessBuilder().command(\"calc\").start()";
		SpelExpression exp = (SpelExpression) parser.parseExpression(expression3);
		// 以下可以执行命令
		// exp.getValue();
		// exp.setValue(new StandardEvaluationContext(), "sss");
		// exp.getValueType();
		// exp.getValueTypeDescriptor();

		// 以下无法执行命令
		// exp.isWritable(new StandardEvaluationContext());
		// exp.getExpressionString();
		// exp.getEvaluationContext();
		// exp.compileExpression();
		// exp.revertToInterpreted();
		// exp.getAST();
		// exp.toStringAST();

	}

}
