package northriver;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class TestProcessBuilder {

	public static void main(String[] args) throws Exception {

		ExpressionParser parser = new SpelExpressionParser();
		Expression exp = parser.parseExpression("T(java.lang.Math).random()");
		Double message = (Double) exp.getValue();


		System.out.println(message);
		
	}
}
